<?php
    require_once __DIR__ .'/../models/dao/daoIkasleak.php';

    $daoIkasleak = new \models\dao\daoIkasleak();
    $ikasleak = $daoIkasleak->selectIkasleak();
    
?>
<html>
<head>
    <title>Ikasleak</title>
</head>
<body>
    console.log("Ikasleak: ", <?php echo json_encode($ikasleak); ?>);
</body>
</html>