<?php
    class Database{
        private $server = "localhost";
        private $user = "root";
        private $pass = "";
        private $db = "ikastola";
        private $connection;

        public function connect(){
            $this->connection = new mysqli($this->server, $this->user, $this->pass, $this->db);

            if ($this->conexion->connect_errno) {
                die("Conexio Errorea: " . $this->conexion->connect_errno);
            }

            return $this->conexion;
        }
    }
    
?>