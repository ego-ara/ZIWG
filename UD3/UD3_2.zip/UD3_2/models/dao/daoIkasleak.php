<?php
namespace dao;
require_once __DIR__ .'/../config/Database.php';
require_once __DIR__ .'/../entity/Ikasleak.php';

class daoIkasleak
{
    public function selectIkasleak(): array{
        $ikasleak = [];
        $sql = "SELECT * FROM ikasleak";

        try{
            $dbConection = new \config\Database();
            $con = $dbConection->getConnection();
            $stmt = $con->prepare($sql);
            $stmt->execute();

            while($row = $stmt->fetch(\PDO::FETCH_ASSOC)){
                $ikasleak[] = new \entity\Ikasleak($row['id'], $row['izena'], $row['email']);
            }

        }catch(\Exception $e){
            error_log("Error al seleccionar ikasleak: " . $e->getMessage());
        }
        return $ikasleak;
    }


}
?>