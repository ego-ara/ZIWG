<?php
    $ikasleak = $this->daoIkasleak->selectIkasleak();
    

?>